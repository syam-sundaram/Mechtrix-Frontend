import { Service } from '@angular/core';

@Service()
export class Tutorialservice {

    constructor(){

}

getEmployee(){
    return [
        {"id":1, "name":"Andrew", "age":30},
        {"id":1, "name":"Andrew", "age":30}
    ]
}

}
