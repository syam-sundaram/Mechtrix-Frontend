import { TestBed } from '@angular/core/testing';

import { Tutorialservice } from './tutorialservice';

describe('Tutorialservice', () => {
  let service: Tutorialservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Tutorialservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
