import { Routes } from '@angular/router';
import { About } from './pages/about/about';
import { Home } from './pages/home/home';
import { Tutorial } from './pages/tutorial/tutorial';

export const routes: Routes = [
   { path: '', redirectTo: 'home', pathMatch: 'full' },
    {path:'home', component:Home},
    {path:'about', component:About},
    {path:'tutorial', component:Tutorial}

    
];
